const {Sequelize} = require('sequelize')
//conexão com BANCO DE DADOS
const sequelize = new Sequelize('feriadosEscola', 'root', 'escola',{
    host:'localhost',
    dialect: 'mysql',
    logging: false
})
module.exports = sequelize;